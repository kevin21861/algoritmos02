<?php 
class rutas{
    public static $rutasValidas = ['home', 'about', 'contact'];
}